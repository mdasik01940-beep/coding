"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import {
  LayoutDashboard,
  Users,
  BookOpen,
  CreditCard,
  Play,
  Award,
  TrendingUp,
  ArrowRight,
} from "lucide-react";

interface Stats {
  totalStudents: number;
  totalCourses: number;
  totalEnrollments: number;
  totalFreeClasses: number;
  totalSuccessStories: number;
}

export default function AdminDashboard() {
  const router = useRouter();
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const userStr = localStorage.getItem("user");
    if (!userStr) {
      router.push("/login");
      return;
    }
    try {
      const user = JSON.parse(userStr);
      if (user.role !== "admin") {
        router.push("/");
        return;
      }
    } catch {
      router.push("/login");
      return;
    }
    fetchStats();
  }, [router]);

  async function fetchStats() {
    try {
      const res = await fetch("/api/admin/stats");
      const data = await res.json();
      setStats(data);
    } catch (error) {
      console.error("Error fetching stats:", error);
    } finally {
      setLoading(false);
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  const cards = [
    {
      title: "Total Students",
      value: stats?.totalStudents || 0,
      icon: Users,
      href: "/admin/students",
      color: "bg-blue-500",
    },
    {
      title: "Total Courses",
      value: stats?.totalCourses || 0,
      icon: BookOpen,
      href: "/admin/courses",
      color: "bg-primary",
    },
    {
      title: "Enrollments",
      value: stats?.totalEnrollments || 0,
      icon: TrendingUp,
      href: "/admin",
      color: "bg-green-500",
    },
    {
      title: "Free Classes",
      value: stats?.totalFreeClasses || 0,
      icon: Play,
      href: "/admin/free-classes",
      color: "bg-orange-500",
    },
    {
      title: "Success Stories",
      value: stats?.totalSuccessStories || 0,
      icon: Award,
      href: "/admin/success-stories",
      color: "bg-pink-500",
    },
    {
      title: "Payment Methods",
      value: "Manage",
      icon: CreditCard,
      href: "/admin/payment-methods",
      color: "bg-purple-500",
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex items-center gap-3">
            <LayoutDashboard className="w-8 h-8 text-primary" />
            <div>
              <h1 className="text-3xl font-bold text-gray-900">
                Admin Dashboard
              </h1>
              <p className="text-gray-600">Manage your COding Center</p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {cards.map((card) => (
            <Link
              key={card.title}
              href={card.href}
              className="group bg-white rounded-2xl p-6 border border-gray-100 hover:shadow-lg transition-all"
            >
              <div className="flex items-start justify-between mb-4">
                <div
                  className={`w-12 h-12 rounded-xl ${card.color} text-white flex items-center justify-center`}
                >
                  <card.icon className="w-6 h-6" />
                </div>
                <ArrowRight className="w-5 h-5 text-gray-300 group-hover:text-primary transition-colors" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-1">
                {card.value}
              </h3>
              <p className="text-sm text-gray-500">{card.title}</p>
            </Link>
          ))}
        </div>

        {/* Quick Actions */}
        <div className="mt-12">
          <h2 className="text-xl font-bold text-gray-900 mb-6">
            Quick Actions
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { label: "Add Course", href: "/admin/courses", desc: "Create a new course" },
              { label: "Add Free Class", href: "/admin/free-classes", desc: "Upload free content" },
              { label: "Add Success Story", href: "/admin/success-stories", desc: "Share student success" },
              { label: "Add Payment Method", href: "/admin/payment-methods", desc: "New payment option" },
            ].map((action) => (
              <Link
                key={action.label}
                href={action.href}
                className="p-5 rounded-xl bg-white border border-gray-100 hover:border-primary/30 hover:shadow-md transition-all"
              >
                <p className="font-semibold text-gray-900">{action.label}</p>
                <p className="text-sm text-gray-500 mt-1">{action.desc}</p>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
