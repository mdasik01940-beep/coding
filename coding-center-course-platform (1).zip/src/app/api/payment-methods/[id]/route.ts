import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { paymentMethods } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await req.json();
    const result = await db
      .update(paymentMethods)
      .set(body)
      .where(eq(paymentMethods.id, parseInt(id)))
      .returning();
    return NextResponse.json(result[0]);
  } catch (error) {
    console.error("Update payment method error:", error);
    return NextResponse.json({ error: "Something went wrong" }, { status: 500 });
  }
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    await db.delete(paymentMethods).where(eq(paymentMethods.id, parseInt(id)));
    return NextResponse.json({ message: "Payment method deleted" });
  } catch (error) {
    console.error("Delete payment method error:", error);
    return NextResponse.json({ error: "Something went wrong" }, { status: 500 });
  }
}
