"use client";

import { useState, useEffect } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import Image from "next/image";
import {
  BookOpen,
  Users,
  Clock,
  Award,
  ArrowLeft,
  CheckCircle,
  ShoppingCart,
  Calendar,
} from "lucide-react";

interface Course {
  id: number;
  title: string;
  description: string;
  price: string;
  discountPrice: string | null;
  image: string;
  duration: string;
  lessons: number;
  instructor: string;
  startDate: string | null;
}

export default function CourseDetailPage() {
  const params = useParams();
  const id = params.id as string;
  const [course, setCourse] = useState<Course | null>(null);
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState<{ id: number; name: string } | null>(null);

  useEffect(() => {
    const storedUser = localStorage.getItem("user");
    if (storedUser) {
      try { setUser(JSON.parse(storedUser)); } catch { setUser(null); }
    }
    fetchCourse();
  }, [id]);

  async function fetchCourse() {
    try {
      const res = await fetch(`/api/courses/${id}`);
      const data = await res.json();
      setCourse(data);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!course) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-gray-500">Course not found.</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <Link href="/courses" className="inline-flex items-center gap-2 text-sm text-gray-500 hover:text-primary transition-colors">
            <ArrowLeft className="w-4 h-4" /> Back to Courses
          </Link>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <div className="relative h-64 md:h-96 rounded-2xl overflow-hidden mb-8">
              <Image src={course.image} alt={course.title} fill className="object-cover" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900 mb-4">{course.title}</h1>
            <div className="flex flex-wrap items-center gap-4 mb-6">
              <span className="flex items-center gap-1 text-sm text-gray-600"><Users className="w-4 h-4 text-primary" /> Instructor: {course.instructor}</span>
              <span className="flex items-center gap-1 text-sm text-gray-600"><Clock className="w-4 h-4 text-primary" /> {course.duration}</span>
              <span className="flex items-center gap-1 text-sm text-gray-600"><BookOpen className="w-4 h-4 text-primary" /> {course.lessons} Lessons</span>
              {course.startDate && (
                <span className="flex items-center gap-1 text-sm text-primary font-medium bg-primary/10 px-3 py-1 rounded-full">
                  <Calendar className="w-4 h-4" /> Starts: {new Date(course.startDate).toLocaleDateString("en-GB")}
                </span>
              )}
            </div>
            <div className="bg-white rounded-2xl p-6 border border-gray-100 mb-6">
              <h2 className="text-xl font-bold text-gray-900 mb-4">Course Description</h2>
              <p className="text-gray-600 leading-relaxed">{course.description}</p>
            </div>
            <div className="bg-white rounded-2xl p-6 border border-gray-100">
              <h2 className="text-xl font-bold text-gray-900 mb-4">What You Will Learn</h2>
              <div className="grid md:grid-cols-2 gap-3">
                {["Hands-on project experience", "Industry best practices", "Real-world problem solving", "Certificate of completion", "Lifetime access to materials", "Community support"].map((item, i) => (
                  <div key={i} className="flex items-center gap-2"><CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" /><span className="text-sm text-gray-600">{item}</span></div>
                ))}
              </div>
            </div>
          </div>

          <div className="lg:col-span-1">
            <div className="sticky top-24 bg-white rounded-2xl p-6 border border-gray-100 shadow-lg">
              <div className="mb-6">
                <div className="flex items-baseline gap-3 mb-2">
                  <span className="text-3xl font-bold text-primary">৳{course.discountPrice || course.price}</span>
                  {course.discountPrice && <span className="text-lg text-gray-400 line-through">৳{course.price}</span>}
                </div>
                {course.discountPrice && (
                  <p className="text-sm text-green-600 font-medium">Save ৳{(parseFloat(course.price) - parseFloat(course.discountPrice)).toFixed(0)}</p>
                )}
              </div>

              {user ? (
                <Link href={`/enroll?course=${course.id}`}
                  className="w-full flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-primary hover:bg-primary-dark text-white font-semibold transition-colors mb-4">
                  <ShoppingCart className="w-5 h-5" /> Enroll Now
                </Link>
              ) : (
                <Link href="/login"
                  className="w-full flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-primary hover:bg-primary-dark text-white font-semibold transition-colors mb-4">
                  Login to Enroll
                </Link>
              )}

              {!user && (
                <p className="text-center text-sm text-gray-500 mb-4">
                  Don&apos;t have an account? <Link href="/register" className="text-primary font-medium hover:underline">Register</Link>
                </p>
              )}

              <div className="space-y-3 pt-4 border-t border-gray-100">
                <div className="flex items-center gap-3 text-sm text-gray-600"><Award className="w-5 h-5 text-primary" /> Certificate of completion</div>
                <div className="flex items-center gap-3 text-sm text-gray-600"><BookOpen className="w-5 h-5 text-primary" /> {course.lessons} video lessons</div>
                <div className="flex items-center gap-3 text-sm text-gray-600"><Clock className="w-5 h-5 text-primary" /> {course.duration} duration</div>
                <div className="flex items-center gap-3 text-sm text-gray-600"><Users className="w-5 h-5 text-primary" /> Expert instructor support</div>
                {course.startDate && (
                  <div className="flex items-center gap-3 text-sm text-gray-600"><Calendar className="w-5 h-5 text-primary" /> Batch starts {new Date(course.startDate).toLocaleDateString("en-GB")}</div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
