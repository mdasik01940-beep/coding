import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq, and } from "drizzle-orm";
import bcrypt from "bcryptjs";

// Step 1: Verify email + phone match
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { email, phone, newPassword } = body;

    if (!email || !phone) {
      return NextResponse.json(
        { error: "Email and phone are required" },
        { status: 400 }
      );
    }

    const userResult = await db
      .select()
      .from(users)
      .where(and(eq(users.email, email), eq(users.phone, phone)));

    if (userResult.length === 0) {
      return NextResponse.json(
        { error: "No account found with this email and phone combination" },
        { status: 404 }
      );
    }

    // If newPassword provided, this is the reset step
    if (newPassword) {
      if (newPassword.length < 6) {
        return NextResponse.json(
          { error: "New password must be at least 6 characters" },
          { status: 400 }
        );
      }
      const hashedPassword = await bcrypt.hash(newPassword, 10);
      await db
        .update(users)
        .set({ password: hashedPassword })
        .where(eq(users.id, userResult[0].id));

      return NextResponse.json({ message: "Password reset successfully" });
    }

    // Otherwise just verification step
    return NextResponse.json({
      message: "Account verified",
      verified: true,
      name: userResult[0].name,
    });
  } catch (error) {
    console.error("Forgot password error:", error);
    return NextResponse.json(
      { error: "Something went wrong" },
      { status: 500 }
    );
  }
}
