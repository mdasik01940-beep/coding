import Link from "next/link";
import Image from "next/image";
import { Code2, Mail, Phone, MapPin } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-gray-900 text-gray-300 pb-20 md:pb-0">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="md:col-span-1">
            <Link href="/" className="flex items-center gap-2 mb-4">
              <div className="w-9 h-9 rounded-lg bg-primary flex items-center justify-center">
                <Code2 className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold text-white">
                COding Center
              </span>
            </Link>
            <p className="text-sm text-gray-400 leading-relaxed">
              Bangladesh&apos;s premier IT training center. We help students build successful careers in technology.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-white font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/" className="text-sm hover:text-primary transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/courses" className="text-sm hover:text-primary transition-colors">
                  Courses
                </Link>
              </li>
              <li>
                <Link href="/support" className="text-sm hover:text-primary transition-colors">
                  Support
                </Link>
              </li>
              <li>
                <Link href="/account" className="text-sm hover:text-primary transition-colors">
                  Account
                </Link>
              </li>
            </ul>
          </div>

          {/* Courses */}
          <div>
            <h3 className="text-white font-semibold mb-4">Popular Courses</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/courses" className="text-sm hover:text-primary transition-colors">
                  Web Development
                </Link>
              </li>
              <li>
                <Link href="/courses" className="text-sm hover:text-primary transition-colors">
                  Mobile Development
                </Link>
              </li>
              <li>
                <Link href="/courses" className="text-sm hover:text-primary transition-colors">
                  Data Science
                </Link>
              </li>
              <li>
                <Link href="/courses" className="text-sm hover:text-primary transition-colors">
                  Cyber Security
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-white font-semibold mb-4">Contact Us</h3>
            <ul className="space-y-3">
              <li>
                <a href="tel:01765094092" className="flex items-center gap-2 text-sm hover:text-primary transition-colors">
                  <Phone className="w-4 h-4 text-primary" />
                  <span>01765094092</span>
                </a>
              </li>
              <li>
                <a href="mailto:info@codingcenter.com" className="flex items-center gap-2 text-sm hover:text-primary transition-colors">
                  <Mail className="w-4 h-4 text-primary" />
                  <span>info@codingcenter.com</span>
                </a>
              </li>
              <li className="flex items-start gap-2 text-sm">
                <MapPin className="w-4 h-4 text-primary mt-0.5" />
                <span>Chini Mosque, Saidpur, Nilphamari</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-10 pt-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-sm text-gray-500">
            &copy; {new Date().getFullYear()} COding Center. All rights reserved.
          </p>
          <div className="flex items-center gap-3">
            <span className="text-sm text-gray-500">Developed by</span>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full overflow-hidden bg-white flex-shrink-0">
                <Image
                  src="/images/exlixsoft-logo.png"
                  alt="Exlixsoft"
                  width={32}
                  height={32}
                  className="object-cover"
                />
              </div>
              <span className="text-sm font-semibold text-white">Exlixsoft</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
