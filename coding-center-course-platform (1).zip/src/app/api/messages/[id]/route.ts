import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { contactMessages } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await req.json();
    const result = await db
      .update(contactMessages)
      .set(body)
      .where(eq(contactMessages.id, parseInt(id)))
      .returning();
    return NextResponse.json(result[0]);
  } catch (error) {
    console.error("Update message error:", error);
    return NextResponse.json(
      { error: "Something went wrong" },
      { status: 500 }
    );
  }
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    await db.delete(contactMessages).where(eq(contactMessages.id, parseInt(id)));
    return NextResponse.json({ message: "Message deleted" });
  } catch (error) {
    console.error("Delete message error:", error);
    return NextResponse.json(
      { error: "Something went wrong" },
      { status: 500 }
    );
  }
}
