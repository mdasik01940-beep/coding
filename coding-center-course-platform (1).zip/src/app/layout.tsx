import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { ConditionalLayout } from "@/components/ConditionalLayout";

export const metadata: Metadata = {
  title: "COding Center - Learn. Code. Succeed.",
  description: "Bangladesh's premier IT training center offering courses in Web Development, Mobile Development, Programming, Data Science, Design and Cyber Security.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="bn">
      <body className="bg-gray-50 text-gray-900 antialiased min-h-screen flex flex-col">
        <ConditionalLayout>{children}</ConditionalLayout>
      </body>
    </html>
  );
}
