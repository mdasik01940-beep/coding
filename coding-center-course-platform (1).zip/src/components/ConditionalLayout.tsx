"use client";

import { usePathname } from "next/navigation";
import { Navbar } from "./Navbar";
import { MobileNav } from "./MobileNav";
import { Footer } from "./Footer";
import { AdminSidebar } from "./AdminSidebar";
import { type ReactNode } from "react";

export function ConditionalLayout({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const isAdmin = pathname?.startsWith("/admin");

  if (isAdmin) {
    return (
      <div className="min-h-screen flex">
        <AdminSidebar />
        <div className="flex-1 ml-0 md:ml-64">
          <main className="min-h-screen">{children}</main>
        </div>
      </div>
    );
  }

  return (
    <>
      <Navbar />
      <main className="flex-1">{children}</main>
      <Footer />
      <MobileNav />
    </>
  );
}
