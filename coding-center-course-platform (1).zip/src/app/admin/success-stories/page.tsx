"use client";

import { useState, useEffect, useRef } from "react";
import { useRouter } from "next/navigation";
import Image from "next/image";
import {
  Award,
  Plus,
  X,
  Loader2,
  Trash2,
  Upload,
  Pencil,
} from "lucide-react";

interface SuccessStory {
  id: number;
  name: string;
  photo: string;
  courseName: string;
  company: string;
  designation: string;
  story: string;
}

export default function AdminSuccessStoriesPage() {
  const router = useRouter();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [stories, setStories] = useState<SuccessStory[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [editingId, setEditingId] = useState<number | null>(null);

  const [formData, setFormData] = useState({
    name: "",
    photo: "",
    courseName: "",
    company: "",
    designation: "",
    story: "",
  });

  useEffect(() => {
    checkAdmin();
    fetchStories();
  }, []);

  function checkAdmin() {
    const userStr = localStorage.getItem("user");
    if (!userStr) { router.push("/login"); return; }
    try {
      const user = JSON.parse(userStr);
      if (user.role !== "admin") router.push("/");
    } catch { router.push("/login"); }
  }

  async function fetchStories() {
    try {
      const res = await fetch("/api/success-stories");
      setStories(await res.json());
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  }

  function resetForm() {
    setFormData({ name: "", photo: "", courseName: "", company: "", designation: "", story: "" });
    setPreviewUrl(null);
    setEditingId(null);
  }

  function startEdit(story: SuccessStory) {
    setEditingId(story.id);
    setFormData({
      name: story.name,
      photo: story.photo,
      courseName: story.courseName,
      company: story.company,
      designation: story.designation,
      story: story.story,
    });
    setPreviewUrl(story.photo);
    setShowForm(true);
  }

  async function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const objectUrl = URL.createObjectURL(file);
    setPreviewUrl(objectUrl);
    setUploading(true);
    try {
      const fd = new FormData();
      fd.append("file", file);
      const res = await fetch("/api/upload", { method: "POST", body: fd });
      const data = await res.json();
      if (res.ok) setFormData(p => ({ ...p, photo: data.url }));
      else { alert(data.error || "Upload failed"); setPreviewUrl(null); }
    } catch { alert("Upload failed"); setPreviewUrl(null); }
    finally { setUploading(false); }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!formData.photo) { alert("Please upload a photo"); return; }
    setSaving(true);
    try {
      const url = editingId ? `/api/success-stories/${editingId}` : "/api/success-stories";
      const method = editingId ? "PUT" : "POST";
      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });
      if (res.ok) {
        setShowForm(false);
        resetForm();
        fetchStories();
      }
    } catch (e) { console.error(e); }
    finally { setSaving(false); }
  }

  async function handleDelete(id: number) {
    if (!confirm("Delete this success story?")) return;
    try {
      await fetch(`/api/success-stories/${id}`, { method: "DELETE" });
      fetchStories();
    } catch (e) { console.error(e); }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-primary animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-8">
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Award className="w-8 h-8 text-primary" />
              <div>
                <h1 className="text-3xl font-bold text-gray-900">Success Stories</h1>
                <p className="text-gray-600">Share student achievements</p>
              </div>
            </div>
            <button onClick={() => { setShowForm(!showForm); if (showForm) resetForm(); }}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-primary hover:bg-primary-dark text-white font-medium transition-colors">
              {showForm ? <X className="w-5 h-5" /> : <Plus className="w-5 h-5" />}
              {showForm ? "Cancel" : "Add Story"}
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {showForm && (
          <div className="bg-white rounded-2xl p-6 border border-gray-100 mb-8">
            <h2 className="text-lg font-bold text-gray-900 mb-4">{editingId ? "Edit Success Story" : "Add Success Story"}</h2>
            <form onSubmit={handleSubmit} className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Student Name *</label>
                <input type="text" value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })} required
                  className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Course Name *</label>
                <input type="text" value={formData.courseName} onChange={e => setFormData({ ...formData, courseName: e.target.value })} required
                  className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Company *</label>
                <input type="text" value={formData.company} onChange={e => setFormData({ ...formData, company: e.target.value })} required
                  className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Designation *</label>
                <input type="text" value={formData.designation} onChange={e => setFormData({ ...formData, designation: e.target.value })} required
                  className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none" />
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1">Photo *</label>
                <div className="flex items-center gap-3">
                  <input ref={fileInputRef} type="file" accept="image/*" onChange={handleFileChange} className="hidden" />
                  <button type="button" onClick={() => fileInputRef.current?.click()} disabled={uploading}
                    className="flex items-center gap-2 px-4 py-2 rounded-xl border border-gray-200 hover:border-primary hover:bg-primary/5 text-gray-700 transition-colors disabled:opacity-50">
                    {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
                    {uploading ? "Uploading..." : "Choose Photo"}
                  </button>
                  {formData.photo && <span className="text-xs text-green-600 font-medium">Photo uploaded</span>}
                </div>
              </div>
              {(previewUrl || formData.photo) && (
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Preview</label>
                  <div className="relative w-24 h-24 rounded-xl overflow-hidden border border-gray-200">
                    <Image src={previewUrl || formData.photo} alt="Preview" fill className="object-cover" />
                  </div>
                </div>
              )}
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1">Story *</label>
                <textarea value={formData.story} onChange={e => setFormData({ ...formData, story: e.target.value })} required rows={4}
                  className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none resize-none" />
              </div>
              <div className="md:col-span-2">
                <button type="submit" disabled={saving || uploading}
                  className="px-6 py-2.5 rounded-xl bg-primary hover:bg-primary-dark text-white font-medium transition-colors disabled:opacity-50">
                  {saving ? "Saving..." : editingId ? "Update Success Story" : "Save Success Story"}
                </button>
              </div>
            </form>
          </div>
        )}

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {stories.map(story => (
            <div key={story.id} className="bg-white rounded-2xl p-6 border border-gray-100 relative group">
              <div className="absolute top-4 right-4 flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-all">
                <button onClick={() => startEdit(story)} className="p-2 rounded-lg text-blue-500 hover:bg-blue-50" title="Edit">
                  <Pencil className="w-4 h-4" />
                </button>
                <button onClick={() => handleDelete(story.id)} className="p-2 rounded-lg text-red-500 hover:bg-red-50" title="Delete">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
              <div className="flex items-center gap-4 mb-4">
                <div className="relative w-14 h-14 rounded-full overflow-hidden">
                  <Image src={story.photo} alt={story.name} fill className="object-cover" />
                </div>
                <div>
                  <h3 className="font-bold text-gray-900">{story.name}</h3>
                  <p className="text-xs text-primary font-medium">{story.designation}</p>
                </div>
              </div>
              <p className="text-sm text-gray-600 mb-4 line-clamp-3">&ldquo;{story.story}&rdquo;</p>
              <div className="pt-3 border-t border-gray-100 space-y-1">
                <p className="text-xs text-gray-500">Course: <span className="text-gray-700 font-medium">{story.courseName}</span></p>
                <p className="text-xs text-gray-500">Now at: <span className="text-gray-700 font-medium">{story.company}</span></p>
              </div>
            </div>
          ))}
        </div>
        {stories.length === 0 && (
          <div className="text-center py-20">
            <Award className="w-12 h-12 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500 text-lg">No success stories yet.</p>
            <p className="text-gray-400 text-sm">Click &quot;Add Story&quot; to create one.</p>
          </div>
        )}
      </div>
    </div>
  );
}
