import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { courses, categories } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const categoryId = searchParams.get("categoryId");

    let result;
    if (categoryId) {
      result = await db
        .select()
        .from(courses)
        .where(eq(courses.categoryId, parseInt(categoryId)));
    } else {
      result = await db.select().from(courses);
    }
    return NextResponse.json(result);
  } catch (error) {
    console.error("Courses error:", error);
    return NextResponse.json({ error: "Something went wrong" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const result = await db.insert(courses).values(body).returning();
    return NextResponse.json(result[0], { status: 201 });
  } catch (error) {
    console.error("Create course error:", error);
    return NextResponse.json({ error: "Something went wrong" }, { status: 500 });
  }
}
