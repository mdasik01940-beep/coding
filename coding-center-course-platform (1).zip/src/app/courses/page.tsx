"use client";

import { useState, useEffect, Suspense } from "react";
import Link from "next/link";
import Image from "next/image";
import { useSearchParams } from "next/navigation";
import {
  BookOpen,
  Users,
  Search,
  Filter,
  ChevronRight,
  Calendar,
} from "lucide-react";

interface Category {
  id: number;
  name: string;
  icon: string;
}

interface Course {
  id: number;
  title: string;
  description: string;
  categoryId: number;
  price: string;
  discountPrice: string | null;
  image: string;
  duration: string;
  lessons: number;
  instructor: string;
  startDate: string | null;
}

function CoursesContent() {
  const searchParams = useSearchParams();
  const categoryParam = searchParams.get("category");
  const [courses, setCourses] = useState<Course[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<number | null>(categoryParam ? parseInt(categoryParam) : null);
  const [searchQuery, setSearchQuery] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => { fetchData(); }, []);

  async function fetchData() {
    try {
      const [courseRes, catRes] = await Promise.all([fetch("/api/courses"), fetch("/api/categories")]);
      setCourses(await courseRes.json());
      setCategories(await catRes.json());
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  }

  const filtered = courses.filter(c => {
    const catMatch = selectedCategory ? c.categoryId === selectedCategory : true;
    const searchMatch = searchQuery === "" || c.title.toLowerCase().includes(searchQuery.toLowerCase()) || c.description.toLowerCase().includes(searchQuery.toLowerCase());
    return catMatch && searchMatch;
  });

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">All Courses</h1>
              <p className="text-gray-600 mt-1">Browse our {courses.length}+ professional courses</p>
            </div>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input type="text" placeholder="Search courses..." value={searchQuery} onChange={e => setSearchQuery(e.target.value)}
                className="pl-10 pr-4 py-2.5 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none w-full md:w-72" />
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex items-center gap-2 mb-6 overflow-x-auto pb-2">
          <Filter className="w-5 h-5 text-gray-400 flex-shrink-0" />
          <button onClick={() => setSelectedCategory(null)}
            className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${selectedCategory === null ? "bg-primary text-white" : "bg-white text-gray-600 hover:bg-gray-100 border border-gray-200"}`}>All</button>
          {categories.map(cat => (
            <button key={cat.id} onClick={() => setSelectedCategory(cat.id)}
              className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${selectedCategory === cat.id ? "bg-primary text-white" : "bg-white text-gray-600 hover:bg-gray-100 border border-gray-200"}`}>{cat.name}</button>
          ))}
        </div>

        {filtered.length === 0 ? (
          <div className="text-center py-20"><p className="text-gray-500 text-lg">No courses found.</p></div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filtered.map(course => (
              <div key={course.id} className="group bg-white rounded-2xl border border-gray-100 overflow-hidden hover:shadow-xl hover:shadow-primary/10 transition-all">
                <div className="relative h-48 overflow-hidden">
                  <Image src={course.image} alt={course.title} fill className="object-cover group-hover:scale-105 transition-transform duration-500" />
                  {course.discountPrice && (
                    <div className="absolute top-3 right-3 bg-primary text-white text-xs font-bold px-3 py-1 rounded-full">
                      {Math.round(((parseFloat(course.price)-parseFloat(course.discountPrice))/parseFloat(course.price))*100)}% OFF
                    </div>
                  )}
                </div>
                <div className="p-5">
                  <h3 className="font-bold text-gray-900 mb-2 line-clamp-1">{course.title}</h3>
                  <p className="text-sm text-gray-500 mb-2 line-clamp-2">{course.description}</p>
                  {course.startDate && (
                    <p className="text-xs text-primary font-medium mb-2 flex items-center gap-1">
                      <Calendar className="w-3 h-3" /> Starts {new Date(course.startDate).toLocaleDateString("en-GB")}
                    </p>
                  )}
                  <div className="flex items-center gap-4 text-xs text-gray-500 mb-4">
                    <span className="flex items-center gap-1"><BookOpen className="w-3.5 h-3.5" />{course.lessons} Lessons</span>
                    <span className="flex items-center gap-1"><Users className="w-3.5 h-3.5" />{course.duration}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-baseline gap-2">
                      <span className="text-xl font-bold text-primary">৳{course.discountPrice || course.price}</span>
                      {course.discountPrice && <span className="text-sm text-gray-400 line-through">৳{course.price}</span>}
                    </div>
                    <Link href={`/courses/${course.id}`} className="inline-flex items-center gap-1 px-4 py-2 rounded-lg bg-primary/10 text-primary text-sm font-semibold hover:bg-primary hover:text-white transition-colors">Details <ChevronRight className="w-4 h-4" /></Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default function CoursesPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    }>
      <CoursesContent />
    </Suspense>
  );
}
