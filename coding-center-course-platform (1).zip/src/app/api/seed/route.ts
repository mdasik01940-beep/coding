import { NextResponse } from "next/server";
import { db } from "@/db";
import {
  categories,
  courses,
  paymentMethods,
  freeClasses,
  successStories,
} from "@/db/schema";

export async function POST() {
  try {
    // Seed categories
    const catResult = await db
      .insert(categories)
      .values([
        { name: "Web Development", icon: "Globe", description: "Learn to build modern websites and web applications" },
        { name: "Mobile Development", icon: "Smartphone", description: "Create Android and iOS applications" },
        { name: "Programming", icon: "Code", description: "Master popular programming languages" },
        { name: "Data Science", icon: "BarChart", description: "Analyze data and build ML models" },
        { name: "Design", icon: "Palette", description: "UI/UX and graphic design courses" },
        { name: "Cyber Security", icon: "Shield", description: "Learn ethical hacking and security" },
      ])
      .returning();

    // Seed courses with start dates
    await db.insert(courses).values([
      {
        title: "Complete Web Development Bootcamp",
        description: "Learn HTML, CSS, JavaScript, React, Node.js and more in this comprehensive bootcamp.",
        categoryId: catResult[0].id,
        price: "15000",
        discountPrice: "12000",
        image: "https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=800",
        duration: "6 months",
        lessons: 120,
        instructor: "Rahim Ahmed",
        startDate: "2026-08-01",
        isActive: true,
      },
      {
        title: "React & Next.js Masterclass",
        description: "Build modern web apps with React, Next.js, TypeScript and Tailwind CSS.",
        categoryId: catResult[0].id,
        price: "8000",
        discountPrice: "6500",
        image: "https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=800",
        duration: "3 months",
        lessons: 60,
        instructor: "Karim Hossain",
        startDate: "2026-08-15",
        isActive: true,
      },
      {
        title: "Flutter Mobile App Development",
        description: "Build beautiful cross-platform mobile apps with Flutter and Dart.",
        categoryId: catResult[1].id,
        price: "10000",
        discountPrice: "8500",
        image: "https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?w=800",
        duration: "4 months",
        lessons: 80,
        instructor: "Sadia Islam",
        startDate: "2026-09-01",
        isActive: true,
      },
      {
        title: "Python Programming Fundamentals",
        description: "Master Python from basics to advanced concepts with real-world projects.",
        categoryId: catResult[2].id,
        price: "6000",
        discountPrice: "5000",
        image: "https://images.unsplash.com/photo-1526379095098-d400fd0bf935?w=800",
        duration: "3 months",
        lessons: 50,
        instructor: "Tanvir Rahman",
        startDate: "2026-08-10",
        isActive: true,
      },
      {
        title: "Data Science with Python",
        description: "Learn pandas, numpy, matplotlib, scikit-learn and build ML models.",
        categoryId: catResult[3].id,
        price: "12000",
        discountPrice: "10000",
        image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800",
        duration: "5 months",
        lessons: 100,
        instructor: "Nusrat Jahan",
        startDate: "2026-09-15",
        isActive: true,
      },
      {
        title: "UI/UX Design Masterclass",
        description: "Learn Figma, design principles, prototyping and user research.",
        categoryId: catResult[4].id,
        price: "7000",
        discountPrice: "5500",
        image: "https://images.unsplash.com/photo-1561070791-2526d30994b5?w=800",
        duration: "3 months",
        lessons: 45,
        instructor: "Farhana Akter",
        startDate: "2026-08-20",
        isActive: true,
      },
      {
        title: "Ethical Hacking & Cyber Security",
        description: "Learn penetration testing, network security and vulnerability assessment.",
        categoryId: catResult[5].id,
        price: "15000",
        discountPrice: "13000",
        image: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=800",
        duration: "6 months",
        lessons: 110,
        instructor: "Hasan Mahmud",
        startDate: "2026-10-01",
        isActive: true,
      },
      {
        title: "Java Programming Complete",
        description: "Master Java programming, OOP concepts and Spring Boot framework.",
        categoryId: catResult[2].id,
        price: "9000",
        discountPrice: "7500",
        image: "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=800",
        duration: "4 months",
        lessons: 70,
        instructor: "Rafiqul Islam",
        startDate: "2026-09-05",
        isActive: true,
      },
    ]);

    // Seed payment methods
    await db.insert(paymentMethods).values([
      { name: "bKash", accountNumber: "01XXXXXXXXX", accountName: "COding Center", icon: "Wallet", isActive: true },
      { name: "Nagad", accountNumber: "01XXXXXXXXX", accountName: "COding Center", icon: "Banknote", isActive: true },
      { name: "Rocket", accountNumber: "01XXXXXXXXX", accountName: "COding Center", icon: "CreditCard", isActive: true },
      { name: "Bank Transfer", bankName: "Dutch-Bangla Bank", accountNumber: "1234567890", accountName: "COding Center Ltd.", icon: "Landmark", isActive: true },
    ]);

    // Seed free classes
    await db.insert(freeClasses).values([
      {
        title: "Introduction to HTML & CSS",
        description: "Learn the basics of web development with HTML and CSS in this free class.",
        videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
        thumbnail: "https://images.unsplash.com/photo-1587620962725-abab7fe55159?w=800",
        categoryId: catResult[0].id,
        instructor: "Rahim Ahmed",
      },
      {
        title: "Python Basics for Beginners",
        description: "Start your programming journey with Python fundamentals.",
        videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
        thumbnail: "https://images.unsplash.com/photo-1526379095098-d400fd0bf935?w=800",
        categoryId: catResult[2].id,
        instructor: "Tanvir Rahman",
      },
      {
        title: "UI Design Principles",
        description: "Learn the core principles of user interface design for free.",
        videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
        thumbnail: "https://images.unsplash.com/photo-1561070791-2526d30994b5?w=800",
        categoryId: catResult[4].id,
        instructor: "Farhana Akter",
      },
    ]);

    // Seed success stories
    await db.insert(successStories).values([
      {
        name: "Abdullah Al Mamun",
        photo: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400",
        courseName: "Complete Web Development Bootcamp",
        company: "Brain Station 23",
        designation: "Senior Frontend Developer",
        story: "After completing the web development bootcamp, I got hired as a junior developer and within 2 years became a senior developer. The practical projects and mentorship were invaluable.",
      },
      {
        name: "Fatema Tuz Zohora",
        photo: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400",
        courseName: "Data Science with Python",
        company: "Pathao",
        designation: "Data Analyst",
        story: "The data science course transformed my career. I went from a marketing role to a data analyst position at a top tech company. The curriculum was perfectly aligned with industry needs.",
      },
      {
        name: "Sakib Al Hasan",
        photo: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400",
        courseName: "Flutter Mobile App Development",
        company: "Chaldal",
        designation: "Mobile App Developer",
        story: "I built my first Flutter app during the course and got hired immediately. Now I lead a team of mobile developers. This course changed my life completely.",
      },
      {
        name: "Nabila Rahman",
        photo: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400",
        courseName: "UI/UX Design Masterclass",
        company: "Robi Axiata",
        designation: "Product Designer",
        story: "The design course gave me the skills and portfolio I needed to land my dream job. The instructors were amazing and the community support was incredible.",
      },
    ]);

    return NextResponse.json({ message: "Database seeded successfully" });
  } catch (error) {
    console.error("Seed error:", error);
    return NextResponse.json({ error: "Something went wrong" }, { status: 500 });
  }
}
