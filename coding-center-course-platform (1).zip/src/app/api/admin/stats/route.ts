import { NextResponse } from "next/server";
import { db } from "@/db";
import { users, courses, enrollments, freeClasses, successStories } from "@/db/schema";
import { sql } from "drizzle-orm";

export async function GET() {
  try {
    const totalStudents = await db.select({ count: sql<number>`count(*)` }).from(users);
    const totalCourses = await db.select({ count: sql<number>`count(*)` }).from(courses);
    const totalEnrollments = await db.select({ count: sql<number>`count(*)` }).from(enrollments);
    const totalFreeClasses = await db.select({ count: sql<number>`count(*)` }).from(freeClasses);
    const totalSuccessStories = await db.select({ count: sql<number>`count(*)` }).from(successStories);

    return NextResponse.json({
      totalStudents: totalStudents[0].count,
      totalCourses: totalCourses[0].count,
      totalEnrollments: totalEnrollments[0].count,
      totalFreeClasses: totalFreeClasses[0].count,
      totalSuccessStories: totalSuccessStories[0].count,
    });
  } catch (error) {
    console.error("Admin stats error:", error);
    return NextResponse.json({ error: "Something went wrong" }, { status: 500 });
  }
}
