"use client";

import { useState, useEffect, Suspense } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import Link from "next/link";
import Image from "next/image";
import {
  ArrowLeft,
  BookOpen,
  Users,
  Clock,
  Calendar,
  CreditCard,
  Wallet,
  Banknote,
  Landmark,
  Loader2,
  CheckCircle,
  Copy,
} from "lucide-react";

interface Course {
  id: number;
  title: string;
  description: string;
  price: string;
  discountPrice: string | null;
  image: string;
  duration: string;
  lessons: number;
  instructor: string;
  startDate: string | null;
}

interface PaymentMethod {
  id: number;
  name: string;
  accountNumber: string | null;
  accountName: string | null;
  bankName: string | null;
  icon: string | null;
}

const iconMap: Record<string, React.ReactNode> = {
  Wallet: <Wallet className="w-6 h-6" />,
  Banknote: <Banknote className="w-6 h-6" />,
  CreditCard: <CreditCard className="w-6 h-6" />,
  Landmark: <Landmark className="w-6 h-6" />,
};

function EnrollContent() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const courseId = searchParams.get("course");

  const [course, setCourse] = useState<Course | null>(null);
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>([]);
  const [selectedMethod, setSelectedMethod] = useState<number | null>(null);
  const [transactionId, setTransactionId] = useState("");
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [user, setUser] = useState<{ id: number } | null>(null);
  const [copied, setCopied] = useState<string | null>(null);

  useEffect(() => {
    const storedUser = localStorage.getItem("user");
    const token = localStorage.getItem("token");
    if (!token || !storedUser) {
      router.push("/login");
      return;
    }
    try {
      setUser(JSON.parse(storedUser));
    } catch {
      router.push("/login");
      return;
    }
    if (!courseId) {
      router.push("/courses");
      return;
    }
    fetchData();
  }, [courseId, router]);

  async function fetchData() {
    try {
      const [courseRes, pmRes] = await Promise.all([
        fetch(`/api/courses/${courseId}`),
        fetch("/api/payment-methods"),
      ]);
      const c = await courseRes.json();
      const pm = await pmRes.json();
      setCourse(c);
      setPaymentMethods(pm);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }

  function copyToClipboard(text: string, label: string) {
    navigator.clipboard.writeText(text);
    setCopied(label);
    setTimeout(() => setCopied(null), 2000);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!selectedMethod || !transactionId.trim() || !user || !course) return;

    setSubmitting(true);
    try {
      const res = await fetch("/api/enrollments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: user.id,
          courseId: course.id,
          paymentMethodId: selectedMethod,
          transactionId: transactionId.trim(),
          amount: course.discountPrice || course.price,
        }),
      });
      if (res.ok) {
        setSubmitted(true);
      } else {
        alert("Enrollment failed. Please try again.");
      }
    } catch {
      alert("Something went wrong.");
    } finally {
      setSubmitting(false);
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-10 h-10 text-primary animate-spin" />
      </div>
    );
  }

  if (!course) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-gray-500">Course not found.</p>
      </div>
    );
  }

  if (submitted) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center px-4">
        <div className="bg-white rounded-2xl p-8 border border-gray-100 text-center max-w-md w-full">
          <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Enrollment Submitted!</h2>
          <p className="text-gray-600 mb-6">
            Your payment is pending verification. Admin will review and approve your enrollment soon.
          </p>
          <div className="flex flex-col gap-3">
            <Link href="/courses" className="px-6 py-3 rounded-xl bg-primary hover:bg-primary-dark text-white font-semibold transition-colors">
              Browse More Courses
            </Link>
            <Link href="/account" className="px-6 py-3 rounded-xl bg-gray-100 hover:bg-gray-200 text-gray-700 font-semibold transition-colors">
              Go to Account
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const finalPrice = course.discountPrice || course.price;

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <Link href={`/courses/${course.id}`} className="inline-flex items-center gap-2 text-sm text-gray-500 hover:text-primary transition-colors">
            <ArrowLeft className="w-4 h-4" /> Back to Course
          </Link>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h1 className="text-2xl font-bold text-gray-900 mb-6">Enroll in Course</h1>

        <div className="grid md:grid-cols-5 gap-8">
          {/* Course Summary */}
          <div className="md:col-span-2">
            <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden sticky top-24">
              <div className="relative h-40">
                <Image src={course.image} alt={course.title} fill className="object-cover" />
              </div>
              <div className="p-5">
                <h3 className="font-bold text-gray-900 mb-2">{course.title}</h3>
                <div className="space-y-2 text-sm text-gray-600">
                  <div className="flex items-center gap-2"><Users className="w-4 h-4 text-primary" /> {course.instructor}</div>
                  <div className="flex items-center gap-2"><Clock className="w-4 h-4 text-primary" /> {course.duration}</div>
                  <div className="flex items-center gap-2"><BookOpen className="w-4 h-4 text-primary" /> {course.lessons} Lessons</div>
                  {course.startDate && (
                    <div className="flex items-center gap-2"><Calendar className="w-4 h-4 text-primary" /> Starts: {new Date(course.startDate).toLocaleDateString("en-GB")}</div>
                  )}
                </div>
                <div className="mt-4 pt-4 border-t border-gray-100">
                  <div className="flex items-baseline gap-2">
                    <span className="text-2xl font-bold text-primary">৳{finalPrice}</span>
                    {course.discountPrice && <span className="text-sm text-gray-400 line-through">৳{course.price}</span>}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Payment Form */}
          <div className="md:col-span-3">
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Payment Methods */}
              <div className="bg-white rounded-2xl p-6 border border-gray-100">
                <h3 className="text-lg font-bold text-gray-900 mb-4">Select Payment Method</h3>
                <div className="space-y-3">
                  {paymentMethods.map(pm => (
                    <label key={pm.id}
                      className={`flex items-center gap-4 p-4 rounded-xl border-2 cursor-pointer transition-all ${
                        selectedMethod === pm.id ? "border-primary bg-primary/5" : "border-gray-100 hover:border-gray-200"
                      }`}>
                      <input type="radio" name="paymentMethod" value={pm.id}
                        checked={selectedMethod === pm.id}
                        onChange={() => setSelectedMethod(pm.id)}
                        className="w-5 h-5 text-primary" />
                      <div className="w-10 h-10 rounded-lg bg-primary/10 text-primary flex items-center justify-center">
                        {iconMap[pm.icon || "Wallet"]}
                      </div>
                      <div className="flex-1">
                        <p className="font-semibold text-gray-900">{pm.name}</p>
                        {pm.accountNumber && (
                          <p className="text-sm text-gray-500 flex items-center gap-1">
                            A/C: {pm.accountNumber}
                            <button type="button" onClick={() => copyToClipboard(pm.accountNumber!, pm.name)}
                              className="p-1 rounded hover:bg-gray-100">
                              {copied === pm.name ? <CheckCircle className="w-3 h-3 text-green-500" /> : <Copy className="w-3 h-3" />}
                            </button>
                          </p>
                        )}
                        {pm.accountName && <p className="text-xs text-gray-400">{pm.accountName}</p>}
                        {pm.bankName && <p className="text-xs text-gray-400">{pm.bankName}</p>}
                      </div>
                    </label>
                  ))}
                </div>
              </div>

              {/* Transaction ID */}
              <div className="bg-white rounded-2xl p-6 border border-gray-100">
                <h3 className="text-lg font-bold text-gray-900 mb-4">Payment Details</h3>
                <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4 mb-4">
                  <p className="text-sm text-yellow-800">
                    <strong>Instructions:</strong> Send <strong>৳{finalPrice}</strong> to your selected payment method above. Then enter the transaction ID below.
                  </p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Transaction ID *</label>
                  <input type="text" value={transactionId} onChange={e => setTransactionId(e.target.value)} required
                    placeholder="Enter your transaction ID"
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none" />
                </div>
              </div>

              <button type="submit" disabled={submitting || !selectedMethod}
                className="w-full flex items-center justify-center gap-2 px-6 py-4 rounded-xl bg-primary hover:bg-primary-dark text-white font-bold text-lg transition-colors disabled:opacity-50">
                {submitting ? <><Loader2 className="w-5 h-5 animate-spin" /> Processing...</> : `Complete Enrollment - ৳${finalPrice}`}
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function EnrollPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-10 h-10 text-primary animate-spin" />
      </div>
    }>
      <EnrollContent />
    </Suspense>
  );
}
