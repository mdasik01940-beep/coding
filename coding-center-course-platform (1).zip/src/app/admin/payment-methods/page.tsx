"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import {
  CreditCard,
  Plus,
  X,
  Loader2,
  Trash2,
  Wallet,
  Banknote,
  Landmark,
  Pencil,
} from "lucide-react";

interface PaymentMethod {
  id: number;
  name: string;
  accountNumber: string | null;
  accountName: string | null;
  bankName: string | null;
  icon: string | null;
  isActive: boolean;
}

const iconMap: Record<string, React.ReactNode> = {
  Wallet: <Wallet className="w-5 h-5" />,
  Banknote: <Banknote className="w-5 h-5" />,
  CreditCard: <CreditCard className="w-5 h-5" />,
  Landmark: <Landmark className="w-5 h-5" />,
};

export default function AdminPaymentMethodsPage() {
  const router = useRouter();
  const [methods, setMethods] = useState<PaymentMethod[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    accountNumber: "",
    accountName: "",
    bankName: "",
    icon: "Wallet",
  });

  useEffect(() => {
    checkAdmin();
    fetchMethods();
  }, []);

  function checkAdmin() {
    const userStr = localStorage.getItem("user");
    if (!userStr) { router.push("/login"); return; }
    try {
      const user = JSON.parse(userStr);
      if (user.role !== "admin") router.push("/");
    } catch { router.push("/login"); }
  }

  async function fetchMethods() {
    try {
      const res = await fetch("/api/payment-methods");
      setMethods(await res.json());
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  }

  function resetForm() {
    setFormData({ name: "", accountNumber: "", accountName: "", bankName: "", icon: "Wallet" });
    setEditingId(null);
  }

  function startEdit(method: PaymentMethod) {
    setEditingId(method.id);
    setFormData({
      name: method.name,
      accountNumber: method.accountNumber || "",
      accountName: method.accountName || "",
      bankName: method.bankName || "",
      icon: method.icon || "Wallet",
    });
    setShowForm(true);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    try {
      const url = editingId ? `/api/payment-methods/${editingId}` : "/api/payment-methods";
      const method = editingId ? "PUT" : "POST";
      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });
      if (res.ok) {
        setShowForm(false);
        resetForm();
        fetchMethods();
      }
    } catch (e) { console.error(e); }
    finally { setSaving(false); }
  }

  async function handleDelete(id: number) {
    if (!confirm("Delete this payment method?")) return;
    try {
      await fetch(`/api/payment-methods/${id}`, { method: "DELETE" });
      fetchMethods();
    } catch (e) { console.error(e); }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-primary animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-8">
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <CreditCard className="w-8 h-8 text-primary" />
              <div>
                <h1 className="text-3xl font-bold text-gray-900">Payment Methods</h1>
                <p className="text-gray-600">Manage payment options for students</p>
              </div>
            </div>
            <button onClick={() => { setShowForm(!showForm); if (showForm) resetForm(); }}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-primary hover:bg-primary-dark text-white font-medium transition-colors">
              {showForm ? <X className="w-5 h-5" /> : <Plus className="w-5 h-5" />}
              {showForm ? "Cancel" : "Add Method"}
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {showForm && (
          <div className="bg-white rounded-2xl p-6 border border-gray-100 mb-8">
            <h2 className="text-lg font-bold text-gray-900 mb-4">{editingId ? "Edit Payment Method" : "Add Payment Method"}</h2>
            <form onSubmit={handleSubmit} className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Method Name *</label>
                <input type="text" value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })} required
                  placeholder="e.g. bKash"
                  className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Icon</label>
                <select value={formData.icon} onChange={e => setFormData({ ...formData, icon: e.target.value })}
                  className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none">
                  <option value="Wallet">Wallet</option>
                  <option value="Banknote">Banknote</option>
                  <option value="CreditCard">Credit Card</option>
                  <option value="Landmark">Bank</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Account Number</label>
                <input type="text" value={formData.accountNumber} onChange={e => setFormData({ ...formData, accountNumber: e.target.value })}
                  className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Account Name</label>
                <input type="text" value={formData.accountName} onChange={e => setFormData({ ...formData, accountName: e.target.value })}
                  className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none" />
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1">Bank Name (if applicable)</label>
                <input type="text" value={formData.bankName} onChange={e => setFormData({ ...formData, bankName: e.target.value })}
                  className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none" />
              </div>
              <div className="md:col-span-2">
                <button type="submit" disabled={saving}
                  className="px-6 py-2.5 rounded-xl bg-primary hover:bg-primary-dark text-white font-medium transition-colors disabled:opacity-50">
                  {saving ? "Saving..." : editingId ? "Update Payment Method" : "Save Payment Method"}
                </button>
              </div>
            </form>
          </div>
        )}

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {methods.map(method => (
            <div key={method.id} className="bg-white rounded-2xl p-6 border border-gray-100 relative group">
              <div className="absolute top-4 right-4 flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-all">
                <button onClick={() => startEdit(method)} className="p-2 rounded-lg text-blue-500 hover:bg-blue-50" title="Edit">
                  <Pencil className="w-4 h-4" />
                </button>
                <button onClick={() => handleDelete(method.id)} className="p-2 rounded-lg text-red-500 hover:bg-red-50" title="Delete">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
              <div className="flex items-start justify-between mb-4">
                <div className="w-12 h-12 rounded-xl bg-primary/10 text-primary flex items-center justify-center">
                  {iconMap[method.icon || "Wallet"]}
                </div>
                <span className={`px-3 py-1 rounded-full text-xs font-medium ${method.isActive ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-600"}`}>
                  {method.isActive ? "Active" : "Inactive"}
                </span>
              </div>
              <h3 className="font-bold text-gray-900 mb-2">{method.name}</h3>
              {method.accountNumber && (
                <p className="text-sm text-gray-600 mb-1"><span className="text-gray-400">Account:</span> {method.accountNumber}</p>
              )}
              {method.accountName && (
                <p className="text-sm text-gray-600 mb-1"><span className="text-gray-400">Name:</span> {method.accountName}</p>
              )}
              {method.bankName && (
                <p className="text-sm text-gray-600"><span className="text-gray-400">Bank:</span> {method.bankName}</p>
              )}
            </div>
          ))}
        </div>
        {methods.length === 0 && (
          <div className="text-center py-20">
            <CreditCard className="w-12 h-12 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500 text-lg">No payment methods yet.</p>
            <p className="text-gray-400 text-sm">Click &quot;Add Method&quot; to create one.</p>
          </div>
        )}
      </div>
    </div>
  );
}
