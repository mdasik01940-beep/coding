import { NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET() {
  try {
    const result = await db
      .select({
        id: users.id,
        name: users.name,
        email: users.email,
        phone: users.phone,
        role: users.role,
        createdAt: users.createdAt,
      })
      .from(users)
      .where(eq(users.role, "student"));
    return NextResponse.json(result);
  } catch (error) {
    console.error("Students error:", error);
    return NextResponse.json({ error: "Something went wrong" }, { status: 500 });
  }
}
