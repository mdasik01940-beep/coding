# COding Center — Deployment Guide

## ⚠️ "Couldn't find any pages or app directory" এরর সমাধান

এই এররটি হয় যখন ডিপ্লয় প্ল্যাটফর্ম `src/app` ফোল্ডার খুঁজে পায় না।
নিচের ধাপগুলো অনুসরণ করুন।

---

## ✅ সঠিক ফোল্ডার স্ট্রাকচার

আপলোড করার সময় `package.json` অবশ্যই **রুট ফোল্ডারে** থাকতে হবে:

```
your-project/
├── src/
│   ├── app/          ← সব পেজ এখানে
│   ├── components/
│   ├── db/
│   └── lib/
├── public/
├── package.json      ← রুটে থাকতে হবে
├── next.config.ts
├── tsconfig.json
└── .env
```

❌ ভুল: `your-project/coding-center/package.json` (একটা extra folder)

---

## 🚀 Vercel-এ ডিপ্লয় (সবচেয়ে সহজ)

1. কোড **GitHub**-এ push করুন
2. [vercel.com](https://vercel.com) → **New Project** → GitHub রিপো সিলেক্ট করুন
3. **Root Directory** = খালি রাখুন (বা `./`)
4. **Framework Preset** = Next.js (অটো ডিটেক্ট হবে)
5. **Environment Variables** যোগ করুন:
   ```
   DATABASE_URL = your_postgres_connection_string
   JWT_SECRET   = any_random_secret_string
   ```
6. **Deploy** ক্লিক করুন

> 💡 ফ্রি PostgreSQL ডাটাবেজের জন্য: [neon.tech](https://neon.tech) বা [supabase.com](https://supabase.com) ব্যবহার করুন

---

## 🗄️ ডাটাবেজ সেটআপ (ডিপ্লয়ের পর)

১. `DATABASE_URL` সেট করার পর টেবিল তৈরি করতে:
```bash
npx drizzle-kit push
```

২. ডেমো ডেটা সিড করতে ব্রাউজারে ভিজিট করুন বা POST রিকোয়েস্ট পাঠান:
```
POST https://your-site.com/api/seed
```

৩. অ্যাডমিন ইউজার তৈরি করতে ডাটাবেজে SQL চালান:
```sql
INSERT INTO users (name, email, phone, password, role)
VALUES ('Admin', 'admin@codingcenter.com', '01765094092',
'$2b$10$19fx5YbbPwhLeK.Gi/39hOUJHjZ1LkjLqvxvsQbdVVAWslsESFc3G', 'admin');
```
(পাসওয়ার্ড: `admin123`)

---

## 🖥️ লোকাল মেশিনে চালাতে

```bash
npm install
npx drizzle-kit push
npm run build
npm start
```

সাইট খুলবে: http://localhost:3000

---

## 📋 চেকলিস্ট

- [ ] `package.json` রুট ফোল্ডারে আছে
- [ ] `src/app` ফোল্ডার আপলোড হয়েছে
- [ ] ZIP-এ কোনো extra wrapper folder নেই
- [ ] `DATABASE_URL` environment variable সেট করা
- [ ] Root Directory খালি বা `./`
