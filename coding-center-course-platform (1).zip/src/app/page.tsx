"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import Image from "next/image";
import {
  Code2,
  ArrowRight,
  Play,
  Star,
  Users,
  BookOpen,
  Award,
  Globe,
  Smartphone,
  BarChart3,
  Palette,
  Shield,
  ChevronRight,
  Calendar,
} from "lucide-react";

interface Category {
  id: number;
  name: string;
  icon: string;
  description: string;
}

interface Course {
  id: number;
  title: string;
  description: string;
  price: string;
  discountPrice: string | null;
  image: string;
  duration: string;
  lessons: number;
  instructor: string;
  startDate: string | null;
}

interface FreeClass {
  id: number;
  title: string;
  description: string;
  thumbnail: string;
  instructor: string;
}

interface SuccessStory {
  id: number;
  name: string;
  photo: string;
  courseName: string;
  company: string;
  designation: string;
  story: string;
}

const iconMap: Record<string, React.ReactNode> = {
  Globe: <Globe className="w-6 h-6" />,
  Smartphone: <Smartphone className="w-6 h-6" />,
  Code: <Code2 className="w-6 h-6" />,
  BarChart: <BarChart3 className="w-6 h-6" />,
  Palette: <Palette className="w-6 h-6" />,
  Shield: <Shield className="w-6 h-6" />,
};

export default function HomePage() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [courses, setCourses] = useState<Course[]>([]);
  const [freeClasses, setFreeClasses] = useState<FreeClass[]>([]);
  const [successStories, setSuccessStories] = useState<SuccessStory[]>([]);
  const [stats, setStats] = useState({ students: 0, courses: 0, instructors: 0, rating: 0 });

  useEffect(() => { fetchData(); }, []);

  async function fetchData() {
    try {
      const [catRes, courseRes, freeRes, storyRes] = await Promise.all([
        fetch("/api/categories"), fetch("/api/courses"), fetch("/api/free-classes"), fetch("/api/success-stories"),
      ]);
      const cats = await catRes.json();
      const cours = await courseRes.json();
      const free = await freeRes.json();
      const stories = await storyRes.json();
      setCategories(cats);
      setCourses(cours.slice(0, 6));
      setFreeClasses(free);
      setSuccessStories(stories);
      setStats({ students: 1200, courses: cours.length, instructors: 15, rating: 4.8 });
    } catch (e) { console.error(e); }
  }

  return (
    <div>
      {/* Hero */}
      <section className="gradient-hero text-white relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 left-10 w-72 h-72 bg-primary rounded-full blur-3xl" />
          <div className="absolute bottom-20 right-10 w-96 h-96 bg-purple-400 rounded-full blur-3xl" />
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-28 relative z-10">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="animate-fade-in-up">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/20 border border-primary/30 text-primary-200 text-sm font-medium mb-6">
                <Star className="w-4 h-4" /> Bangladesh&apos;s #1 IT Training Center
              </div>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-6">
                Learn to Code, <br /><span className="text-primary-light">Build Your Future</span>
              </h1>
              <p className="text-lg text-gray-300 mb-8 max-w-lg">
                Master in-demand tech skills with expert instructors. Join 1200+ students who have transformed their careers through our courses.
              </p>
              <div className="flex flex-wrap gap-4">
                <Link href="/courses" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-primary hover:bg-primary-dark text-white font-semibold transition-colors">
                  Explore Courses <ArrowRight className="w-4 h-4" />
                </Link>
                <Link href="/register" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-white/10 hover:bg-white/20 text-white font-semibold border border-white/20 transition-colors">
                  Get Started
                </Link>
              </div>
              <div className="flex items-center gap-6 mt-10">
                <div className="flex -space-x-3">
                  {[1,2,3,4].map(i => (
                    <div key={i} className="w-10 h-10 rounded-full border-2 border-gray-900 bg-gray-700 flex items-center justify-center text-xs font-bold">{String.fromCharCode(64+i)}</div>
                  ))}
                </div>
                <div>
                  <div className="flex items-center gap-1">
                    {[1,2,3,4,5].map(i => <Star key={i} className="w-4 h-4 text-yellow-400 fill-yellow-400" />)}
                  </div>
                  <p className="text-sm text-gray-400">Trusted by 1200+ students</p>
                </div>
              </div>
            </div>
            <div className="hidden md:block relative">
              <div className="relative z-10 animate-float">
                <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-6 border border-white/10 shadow-2xl">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 rounded-lg bg-primary flex items-center justify-center"><Code2 className="w-5 h-5 text-white" /></div>
                    <div><p className="font-semibold">Web Development</p><p className="text-sm text-gray-400">120 Lessons</p></div>
                  </div>
                  <div className="space-y-2">
                    <div className="h-2 bg-gray-700 rounded-full overflow-hidden"><div className="h-full w-3/4 bg-primary rounded-full" /></div>
                    <p className="text-xs text-gray-400">75% Complete</p>
                  </div>
                </div>
                <div className="absolute -bottom-4 -right-4 bg-white/5 backdrop-blur-sm rounded-xl p-4 border border-white/10 shadow-xl">
                  <div className="flex items-center gap-2"><Award className="w-5 h-5 text-yellow-400" /><span className="text-sm font-medium">Certificate Earned!</span></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-12 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {[{icon: Users, label: "Students", value: `${stats.students}+`}, {icon: BookOpen, label: "Courses", value: `${stats.courses}+`}, {icon: Award, label: "Instructors", value: `${stats.instructors}+`}, {icon: Star, label: "Rating", value: `${stats.rating}/5`}].map((s, i) => (
              <div key={i} className="text-center p-6 rounded-2xl bg-gray-50 hover:bg-primary-50 transition-colors">
                <s.icon className="w-8 h-8 text-primary mx-auto mb-3" />
                <p className="text-2xl font-bold text-gray-900">{s.value}</p>
                <p className="text-sm text-gray-500">{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Explore by Category</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">Choose from our wide range of categories and start your learning journey today.</p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {categories.map(cat => (
              <Link key={cat.id} href={`/courses?category=${cat.id}`}
                className="group p-6 rounded-2xl bg-white border border-gray-100 hover:border-primary/30 hover:shadow-lg hover:shadow-primary/10 transition-all text-center">
                <div className="w-14 h-14 rounded-xl bg-primary/10 text-primary flex items-center justify-center mx-auto mb-4 group-hover:bg-primary group-hover:text-white transition-colors">
                  {iconMap[cat.icon] || <Code2 className="w-6 h-6" />}
                </div>
                <h3 className="font-semibold text-gray-900 text-sm mb-1">{cat.name}</h3>
                <p className="text-xs text-gray-500 line-clamp-2">{cat.description}</p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Courses */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-12">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-2">Featured Courses</h2>
              <p className="text-gray-600">Hand-picked courses to help you start your tech career.</p>
            </div>
            <Link href="/courses" className="hidden md:inline-flex items-center gap-2 text-primary font-semibold hover:underline">View All <ChevronRight className="w-4 h-4" /></Link>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {courses.map(course => (
              <div key={course.id} className="group bg-white rounded-2xl border border-gray-100 overflow-hidden hover:shadow-xl hover:shadow-primary/10 transition-all">
                <div className="relative h-48 overflow-hidden">
                  <Image src={course.image} alt={course.title} fill className="object-cover group-hover:scale-105 transition-transform duration-500" />
                  <div className="absolute top-3 right-3 bg-primary text-white text-xs font-bold px-3 py-1 rounded-full">
                    {course.discountPrice ? `${Math.round(((parseFloat(course.price)-parseFloat(course.discountPrice))/parseFloat(course.price))*100)}% OFF` : "Popular"}
                  </div>
                </div>
                <div className="p-5">
                  <h3 className="font-bold text-gray-900 mb-2 line-clamp-1">{course.title}</h3>
                  <p className="text-sm text-gray-500 mb-3 line-clamp-2">{course.description}</p>
                  {course.startDate && (
                    <p className="text-xs text-primary font-medium mb-2 flex items-center gap-1">
                      <Calendar className="w-3 h-3" /> Starts {new Date(course.startDate).toLocaleDateString("en-GB")}
                    </p>
                  )}
                  <div className="flex items-center gap-4 text-xs text-gray-500 mb-4">
                    <span className="flex items-center gap-1"><BookOpen className="w-3.5 h-3.5" />{course.lessons} Lessons</span>
                    <span className="flex items-center gap-1"><Users className="w-3.5 h-3.5" />{course.duration}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-baseline gap-2">
                      <span className="text-xl font-bold text-primary">৳{course.discountPrice || course.price}</span>
                      {course.discountPrice && <span className="text-sm text-gray-400 line-through">৳{course.price}</span>}
                    </div>
                    <Link href={`/courses/${course.id}`} className="px-4 py-2 rounded-lg bg-primary/10 text-primary text-sm font-semibold hover:bg-primary hover:text-white transition-colors">Details</Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-8 text-center md:hidden">
            <Link href="/courses" className="inline-flex items-center gap-2 text-primary font-semibold">View All Courses <ChevronRight className="w-4 h-4" /></Link>
          </div>
        </div>
      </section>

      {/* Free Classes */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Free Classes</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">Start learning for free with our curated selection of beginner-friendly classes.</p>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {freeClasses.map(cls => (
              <div key={cls.id} className="group bg-white rounded-2xl border border-gray-100 overflow-hidden hover:shadow-lg transition-all">
                <div className="relative h-48">
                  <Image src={cls.thumbnail} alt={cls.title} fill className="object-cover" />
                  <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <div className="w-14 h-14 rounded-full bg-white/90 flex items-center justify-center"><Play className="w-6 h-6 text-primary ml-1" /></div>
                  </div>
                  <div className="absolute top-3 left-3 bg-green-500 text-white text-xs font-bold px-3 py-1 rounded-full">FREE</div>
                </div>
                <div className="p-5">
                  <h3 className="font-bold text-gray-900 mb-2">{cls.title}</h3>
                  <p className="text-sm text-gray-500 mb-3 line-clamp-2">{cls.description}</p>
                  <p className="text-xs text-gray-400">By {cls.instructor}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Success Stories */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Success Stories</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">See how our students transformed their careers after completing our courses.</p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {successStories.map(story => (
              <div key={story.id} className="bg-gray-50 rounded-2xl p-6 hover:shadow-lg transition-all">
                <div className="flex items-center gap-4 mb-4">
                  <div className="relative w-14 h-14 rounded-full overflow-hidden">
                    <Image src={story.photo} alt={story.name} fill className="object-cover" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">{story.name}</h4>
                    <p className="text-xs text-primary font-medium">{story.designation}</p>
                  </div>
                </div>
                <p className="text-sm text-gray-600 mb-3 line-clamp-3">&ldquo;{story.story}&rdquo;</p>
                <div className="pt-3 border-t border-gray-200">
                  <p className="text-xs text-gray-500">Course: <span className="text-gray-700 font-medium">{story.courseName}</span></p>
                  <p className="text-xs text-gray-500">Now at: <span className="text-gray-700 font-medium">{story.company}</span></p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="gradient-primary rounded-3xl p-8 md:p-16 text-center text-white relative overflow-hidden">
            <div className="absolute inset-0 opacity-20">
              <div className="absolute top-0 left-0 w-64 h-64 bg-white rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2" />
              <div className="absolute bottom-0 right-0 w-64 h-64 bg-white rounded-full blur-3xl translate-x-1/2 translate-y-1/2" />
            </div>
            <div className="relative z-10">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to Start Your Journey?</h2>
              <p className="text-lg text-white/80 mb-8 max-w-2xl mx-auto">Join thousands of students who have already transformed their careers. Enroll today and get started!</p>
              <div className="flex flex-wrap justify-center gap-4">
                <Link href="/register" className="inline-flex items-center gap-2 px-8 py-4 rounded-xl bg-white text-primary font-bold hover:bg-gray-100 transition-colors">Create Account <ArrowRight className="w-5 h-5" /></Link>
                <Link href="/courses" className="inline-flex items-center gap-2 px-8 py-4 rounded-xl bg-white/20 text-white font-bold hover:bg-white/30 transition-colors border border-white/30">Browse Courses</Link>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
