import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { freeClasses } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await req.json();
    const result = await db
      .update(freeClasses)
      .set(body)
      .where(eq(freeClasses.id, parseInt(id)))
      .returning();
    return NextResponse.json(result[0]);
  } catch (error) {
    console.error("Update free class error:", error);
    return NextResponse.json({ error: "Something went wrong" }, { status: 500 });
  }
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    await db.delete(freeClasses).where(eq(freeClasses.id, parseInt(id)));
    return NextResponse.json({ message: "Free class deleted" });
  } catch (error) {
    console.error("Delete free class error:", error);
    return NextResponse.json({ error: "Something went wrong" }, { status: 500 });
  }
}
