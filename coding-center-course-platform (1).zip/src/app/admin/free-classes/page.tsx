"use client";

import { useState, useEffect, useRef } from "react";
import { useRouter } from "next/navigation";
import Image from "next/image";
import {
  Play,
  Plus,
  X,
  Loader2,
  Trash2,
  Upload,
  Pencil,
} from "lucide-react";

interface Category {
  id: number;
  name: string;
}

interface FreeClass {
  id: number;
  title: string;
  description: string;
  videoUrl: string;
  thumbnail: string;
  categoryId: number;
  instructor: string;
}

export default function AdminFreeClassesPage() {
  const router = useRouter();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [classes, setClasses] = useState<FreeClass[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [editingId, setEditingId] = useState<number | null>(null);

  const [formData, setFormData] = useState({
    title: "",
    description: "",
    videoUrl: "",
    thumbnail: "",
    categoryId: "",
    instructor: "",
  });

  useEffect(() => {
    checkAdmin();
    fetchData();
  }, []);

  function checkAdmin() {
    const userStr = localStorage.getItem("user");
    if (!userStr) { router.push("/login"); return; }
    try {
      const user = JSON.parse(userStr);
      if (user.role !== "admin") router.push("/");
    } catch { router.push("/login"); }
  }

  async function fetchData() {
    try {
      const [classRes, catRes] = await Promise.all([
        fetch("/api/free-classes"),
        fetch("/api/categories"),
      ]);
      setClasses(await classRes.json());
      setCategories(await catRes.json());
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  }

  function resetForm() {
    setFormData({ title: "", description: "", videoUrl: "", thumbnail: "", categoryId: "", instructor: "" });
    setPreviewUrl(null);
    setEditingId(null);
  }

  function startEdit(cls: FreeClass) {
    setEditingId(cls.id);
    setFormData({
      title: cls.title,
      description: cls.description,
      videoUrl: cls.videoUrl,
      thumbnail: cls.thumbnail,
      categoryId: String(cls.categoryId),
      instructor: cls.instructor,
    });
    setPreviewUrl(cls.thumbnail);
    setShowForm(true);
  }

  async function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const objectUrl = URL.createObjectURL(file);
    setPreviewUrl(objectUrl);
    setUploading(true);
    try {
      const fd = new FormData();
      fd.append("file", file);
      const res = await fetch("/api/upload", { method: "POST", body: fd });
      const data = await res.json();
      if (res.ok) setFormData(p => ({ ...p, thumbnail: data.url }));
      else { alert(data.error || "Upload failed"); setPreviewUrl(null); }
    } catch { alert("Upload failed"); setPreviewUrl(null); }
    finally { setUploading(false); }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!formData.thumbnail) { alert("Please upload a thumbnail"); return; }
    setSaving(true);
    try {
      const body = { ...formData, categoryId: parseInt(formData.categoryId) };
      const url = editingId ? `/api/free-classes/${editingId}` : "/api/free-classes";
      const method = editingId ? "PUT" : "POST";
      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      if (res.ok) {
        setShowForm(false);
        resetForm();
        fetchData();
      }
    } catch (e) { console.error(e); }
    finally { setSaving(false); }
  }

  async function handleDelete(id: number) {
    if (!confirm("Delete this free class?")) return;
    try {
      await fetch(`/api/free-classes/${id}`, { method: "DELETE" });
      fetchData();
    } catch (e) { console.error(e); }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-primary animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-8">
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Play className="w-8 h-8 text-primary" />
              <div>
                <h1 className="text-3xl font-bold text-gray-900">Free Classes</h1>
                <p className="text-gray-600">Manage free learning content</p>
              </div>
            </div>
            <button onClick={() => { setShowForm(!showForm); if (showForm) resetForm(); }}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-primary hover:bg-primary-dark text-white font-medium transition-colors">
              {showForm ? <X className="w-5 h-5" /> : <Plus className="w-5 h-5" />}
              {showForm ? "Cancel" : "Add Class"}
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {showForm && (
          <div className="bg-white rounded-2xl p-6 border border-gray-100 mb-8">
            <h2 className="text-lg font-bold text-gray-900 mb-4">{editingId ? "Edit Free Class" : "Add Free Class"}</h2>
            <form onSubmit={handleSubmit} className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Title *</label>
                <input type="text" value={formData.title} onChange={e => setFormData({ ...formData, title: e.target.value })} required
                  className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Category *</label>
                <select value={formData.categoryId} onChange={e => setFormData({ ...formData, categoryId: e.target.value })} required
                  className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none">
                  <option value="">Select Category</option>
                  {categories.map(cat => <option key={cat.id} value={cat.id}>{cat.name}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Instructor *</label>
                <input type="text" value={formData.instructor} onChange={e => setFormData({ ...formData, instructor: e.target.value })} required
                  className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Video URL *</label>
                <input type="url" value={formData.videoUrl} onChange={e => setFormData({ ...formData, videoUrl: e.target.value })} required
                  placeholder="https://youtube.com/embed/..."
                  className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none" />
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1">Thumbnail *</label>
                <div className="flex items-center gap-3">
                  <input ref={fileInputRef} type="file" accept="image/*" onChange={handleFileChange} className="hidden" />
                  <button type="button" onClick={() => fileInputRef.current?.click()} disabled={uploading}
                    className="flex items-center gap-2 px-4 py-2 rounded-xl border border-gray-200 hover:border-primary hover:bg-primary/5 text-gray-700 transition-colors disabled:opacity-50">
                    {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
                    {uploading ? "Uploading..." : "Choose Thumbnail"}
                  </button>
                  {formData.thumbnail && <span className="text-xs text-green-600 font-medium">Thumbnail uploaded</span>}
                </div>
              </div>
              {(previewUrl || formData.thumbnail) && (
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Preview</label>
                  <div className="relative w-full h-48 rounded-xl overflow-hidden border border-gray-200">
                    <Image src={previewUrl || formData.thumbnail} alt="Preview" fill className="object-cover" />
                  </div>
                </div>
              )}
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1">Description *</label>
                <textarea value={formData.description} onChange={e => setFormData({ ...formData, description: e.target.value })} required rows={3}
                  className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none resize-none" />
              </div>
              <div className="md:col-span-2">
                <button type="submit" disabled={saving || uploading}
                  className="px-6 py-2.5 rounded-xl bg-primary hover:bg-primary-dark text-white font-medium transition-colors disabled:opacity-50">
                  {saving ? "Saving..." : editingId ? "Update Free Class" : "Save Free Class"}
                </button>
              </div>
            </form>
          </div>
        )}

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {classes.map(cls => (
            <div key={cls.id} className="bg-white rounded-2xl border border-gray-100 overflow-hidden relative group">
              <div className="absolute top-3 right-3 z-10 flex items-center gap-1">
                <button onClick={() => startEdit(cls)} className="p-2 rounded-lg bg-white/80 text-blue-500 hover:bg-blue-50 opacity-0 group-hover:opacity-100 transition-all" title="Edit">
                  <Pencil className="w-4 h-4" />
                </button>
                <button onClick={() => handleDelete(cls.id)} className="p-2 rounded-lg bg-white/80 text-red-500 hover:bg-red-50 opacity-0 group-hover:opacity-100 transition-all" title="Delete">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
              <div className="relative h-48">
                <Image src={cls.thumbnail} alt={cls.title} fill className="object-cover" />
                <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                  <div className="w-14 h-14 rounded-full bg-white/90 flex items-center justify-center">
                    <Play className="w-6 h-6 text-primary ml-1" />
                  </div>
                </div>
              </div>
              <div className="p-4">
                <h3 className="font-bold text-gray-900 mb-1">{cls.title}</h3>
                <p className="text-sm text-gray-500 mb-2">By {cls.instructor}</p>
                <p className="text-xs text-gray-400 line-clamp-2">{cls.description}</p>
              </div>
            </div>
          ))}
        </div>
        {classes.length === 0 && (
          <div className="text-center py-20">
            <Play className="w-12 h-12 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500 text-lg">No free classes yet.</p>
            <p className="text-gray-400 text-sm">Click &quot;Add Class&quot; to create one.</p>
          </div>
        )}
      </div>
    </div>
  );
}
