import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { successStories } from "@/db/schema";

export async function GET() {
  try {
    const result = await db.select().from(successStories);
    return NextResponse.json(result);
  } catch (error) {
    console.error("Success stories error:", error);
    return NextResponse.json({ error: "Something went wrong" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const result = await db.insert(successStories).values(body).returning();
    return NextResponse.json(result[0], { status: 201 });
  } catch (error) {
    console.error("Create success story error:", error);
    return NextResponse.json({ error: "Something went wrong" }, { status: 500 });
  }
}
