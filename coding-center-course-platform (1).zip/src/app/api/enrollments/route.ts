import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { enrollments, courses, users, paymentMethods } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET() {
  try {
    const result = await db.select().from(enrollments);
    return NextResponse.json(result);
  } catch (error) {
    console.error("Enrollments error:", error);
    return NextResponse.json({ error: "Something went wrong" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { userId, courseId, paymentMethodId, transactionId, amount } = body;

    const result = await db
      .insert(enrollments)
      .values({
        userId,
        courseId,
        paymentMethodId,
        transactionId,
        amount,
        status: "pending",
      })
      .returning();

    return NextResponse.json(result[0], { status: 201 });
  } catch (error) {
    console.error("Create enrollment error:", error);
    return NextResponse.json({ error: "Something went wrong" }, { status: 500 });
  }
}
