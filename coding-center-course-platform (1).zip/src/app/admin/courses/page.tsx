"use client";

import { useState, useEffect, useRef } from "react";
import { useRouter } from "next/navigation";
import Image from "next/image";
import {
  Plus,
  X,
  Loader2,
  Trash2,
  BookOpen,
  Upload,
  FolderOpen,
  Calendar,
  Pencil,
} from "lucide-react";

interface Category {
  id: number;
  name: string;
  icon: string;
  description: string;
}

interface Course {
  id: number;
  title: string;
  description: string;
  categoryId: number;
  price: string;
  discountPrice: string | null;
  image: string;
  duration: string;
  lessons: number;
  instructor: string;
  startDate: string | null;
}

export default function AdminCoursesPage() {
  const router = useRouter();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [courses, setCourses] = useState<Course[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [showCourseForm, setShowCourseForm] = useState(false);
  const [showCategoryForm, setShowCategoryForm] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [editingId, setEditingId] = useState<number | null>(null);

  const [courseForm, setCourseForm] = useState({
    title: "",
    description: "",
    categoryId: "",
    price: "",
    discountPrice: "",
    image: "",
    duration: "",
    lessons: "",
    instructor: "",
    startDate: "",
  });

  const [categoryForm, setCategoryForm] = useState({
    name: "",
    icon: "Code",
    description: "",
  });

  const iconOptions = [
    "Globe", "Smartphone", "Code", "BarChart", "Palette",
    "Shield", "Database", "Cloud", "Cpu", "Terminal",
  ];

  useEffect(() => {
    checkAdmin();
    fetchData();
  }, []);

  function checkAdmin() {
    const userStr = localStorage.getItem("user");
    if (!userStr) { router.push("/login"); return; }
    try {
      const user = JSON.parse(userStr);
      if (user.role !== "admin") router.push("/");
    } catch { router.push("/login"); }
  }

  async function fetchData() {
    try {
      const [courseRes, catRes] = await Promise.all([
        fetch("/api/courses"), fetch("/api/categories"),
      ]);
      setCourses(await courseRes.json());
      setCategories(await catRes.json());
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  }

  function resetCourseForm() {
    setCourseForm({ title: "", description: "", categoryId: "", price: "", discountPrice: "", image: "", duration: "", lessons: "", instructor: "", startDate: "" });
    setPreviewUrl(null);
    setEditingId(null);
  }

  function startEdit(course: Course) {
    setEditingId(course.id);
    setCourseForm({
      title: course.title,
      description: course.description,
      categoryId: String(course.categoryId),
      price: course.price,
      discountPrice: course.discountPrice || "",
      image: course.image,
      duration: course.duration,
      lessons: String(course.lessons),
      instructor: course.instructor,
      startDate: course.startDate || "",
    });
    setPreviewUrl(course.image);
    setShowCourseForm(true);
    setShowCategoryForm(false);
  }

  async function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const objectUrl = URL.createObjectURL(file);
    setPreviewUrl(objectUrl);
    setUploading(true);
    try {
      const fd = new FormData();
      fd.append("file", file);
      const res = await fetch("/api/upload", { method: "POST", body: fd });
      const data = await res.json();
      if (res.ok) setCourseForm(p => ({ ...p, image: data.url }));
      else { alert(data.error || "Upload failed"); setPreviewUrl(null); }
    } catch { alert("Upload failed"); setPreviewUrl(null); }
    finally { setUploading(false); }
  }

  async function handleCourseSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!courseForm.image) { alert("Please upload a course image"); return; }
    setSaving(true);
    try {
      const body = {
        ...courseForm,
        categoryId: parseInt(courseForm.categoryId),
        price: courseForm.price,
        discountPrice: courseForm.discountPrice || null,
        lessons: parseInt(courseForm.lessons),
      };
      const url = editingId ? `/api/courses/${editingId}` : "/api/courses";
      const method = editingId ? "PUT" : "POST";
      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      if (res.ok) {
        setShowCourseForm(false);
        resetCourseForm();
        fetchData();
      }
    } catch (e) { console.error(e); }
    finally { setSaving(false); }
  }

  async function handleCategorySubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    try {
      const res = await fetch("/api/categories", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify(categoryForm),
      });
      if (res.ok) {
        setShowCategoryForm(false);
        setCategoryForm({ name: "", icon: "Code", description: "" });
        fetchData();
      }
    } catch (e) { console.error(e); }
    finally { setSaving(false); }
  }

  async function handleDeleteCourse(id: number) {
    if (!confirm("Delete this course?")) return;
    await fetch(`/api/courses/${id}`, { method: "DELETE" });
    fetchData();
  }

  async function handleDeleteCategory(id: number) {
    if (!confirm("Delete this category?")) return;
    await fetch(`/api/categories/${id}`, { method: "DELETE" });
    fetchData();
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-primary animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-8">
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <BookOpen className="w-8 h-8 text-primary" />
              <div>
                <h1 className="text-3xl font-bold text-gray-900">Manage Courses</h1>
                <p className="text-gray-600">Add, edit or remove courses</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button onClick={() => { setShowCategoryForm(!showCategoryForm); setShowCourseForm(false); resetCourseForm(); }}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white border border-gray-200 hover:border-primary text-gray-700 font-medium transition-colors">
                {showCategoryForm ? <X className="w-5 h-5" /> : <FolderOpen className="w-5 h-5" />} Categories
              </button>
              <button onClick={() => { setShowCourseForm(!showCourseForm); setShowCategoryForm(false); if (showCourseForm) resetCourseForm(); }}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-primary hover:bg-primary-dark text-white font-medium transition-colors">
                {showCourseForm ? <X className="w-5 h-5" /> : <Plus className="w-5 h-5" />}
                {showCourseForm ? "Cancel" : "Add Course"}
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Category Form */}
        {showCategoryForm && (
          <div className="bg-white rounded-2xl p-6 border border-gray-100 mb-8">
            <h2 className="text-lg font-bold text-gray-900 mb-4">Manage Categories</h2>
            <form onSubmit={handleCategorySubmit} className="grid md:grid-cols-3 gap-4 mb-6 pb-6 border-b border-gray-100">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Category Name</label>
                <input type="text" value={categoryForm.name} onChange={e => setCategoryForm({ ...categoryForm, name: e.target.value })} required
                  className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none" placeholder="e.g. Web Development" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Icon</label>
                <select value={categoryForm.icon} onChange={e => setCategoryForm({ ...categoryForm, icon: e.target.value })}
                  className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none">
                  {iconOptions.map(i => <option key={i} value={i}>{i}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                <div className="flex gap-2">
                  <input type="text" value={categoryForm.description} onChange={e => setCategoryForm({ ...categoryForm, description: e.target.value })}
                    className="flex-1 px-4 py-2 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none" placeholder="Short description" />
                  <button type="submit" disabled={saving} className="px-4 py-2 rounded-xl bg-primary hover:bg-primary-dark text-white font-medium disabled:opacity-50">{saving ? "..." : "Add"}</button>
                </div>
              </div>
            </form>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-3">
              {categories.map(cat => (
                <div key={cat.id} className="flex items-center justify-between p-3 rounded-xl bg-gray-50 border border-gray-100">
                  <div><p className="font-medium text-gray-900">{cat.name}</p><p className="text-xs text-gray-500">Icon: {cat.icon}</p></div>
                  <button onClick={() => handleDeleteCategory(cat.id)} className="p-2 rounded-lg text-red-500 hover:bg-red-50"><Trash2 className="w-4 h-4" /></button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Course Form */}
        {showCourseForm && (
          <div className="bg-white rounded-2xl p-6 border border-gray-100 mb-8">
            <h2 className="text-lg font-bold text-gray-900 mb-4">{editingId ? "Edit Course" : "Add New Course"}</h2>
            <form onSubmit={handleCourseSubmit} className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Title *</label>
                <input type="text" value={courseForm.title} onChange={e => setCourseForm({ ...courseForm, title: e.target.value })} required
                  className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Category *</label>
                <select value={courseForm.categoryId} onChange={e => setCourseForm({ ...courseForm, categoryId: e.target.value })} required
                  className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none">
                  <option value="">Select Category</option>
                  {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Price (৳) *</label>
                <input type="number" value={courseForm.price} onChange={e => setCourseForm({ ...courseForm, price: e.target.value })} required
                  className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Discount Price (৳)</label>
                <input type="number" value={courseForm.discountPrice} onChange={e => setCourseForm({ ...courseForm, discountPrice: e.target.value })}
                  className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Duration *</label>
                <input type="text" value={courseForm.duration} onChange={e => setCourseForm({ ...courseForm, duration: e.target.value })} required placeholder="e.g. 3 months"
                  className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Lessons *</label>
                <input type="number" value={courseForm.lessons} onChange={e => setCourseForm({ ...courseForm, lessons: e.target.value })} required
                  className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Instructor *</label>
                <input type="text" value={courseForm.instructor} onChange={e => setCourseForm({ ...courseForm, instructor: e.target.value })} required
                  className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Start Date</label>
                <input type="date" value={courseForm.startDate} onChange={e => setCourseForm({ ...courseForm, startDate: e.target.value })}
                  className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Course Image *</label>
                <div className="flex items-center gap-3">
                  <input ref={fileInputRef} type="file" accept="image/*" onChange={handleFileChange} className="hidden" />
                  <button type="button" onClick={() => fileInputRef.current?.click()} disabled={uploading}
                    className="flex items-center gap-2 px-4 py-2 rounded-xl border border-gray-200 hover:border-primary hover:bg-primary/5 text-gray-700 transition-colors disabled:opacity-50">
                    {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
                    {uploading ? "Uploading..." : "Choose Image"}
                  </button>
                  {courseForm.image && <span className="text-xs text-green-600 font-medium">Image uploaded</span>}
                </div>
              </div>
              {(previewUrl || courseForm.image) && (
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Preview</label>
                  <div className="relative w-full h-48 rounded-xl overflow-hidden border border-gray-200">
                    <Image src={previewUrl || courseForm.image} alt="Preview" fill className="object-cover" />
                  </div>
                </div>
              )}
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1">Description *</label>
                <textarea value={courseForm.description} onChange={e => setCourseForm({ ...courseForm, description: e.target.value })} required rows={3}
                  className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none resize-none" />
              </div>
              <div className="md:col-span-2">
                <button type="submit" disabled={saving || uploading}
                  className="px-6 py-2.5 rounded-xl bg-primary hover:bg-primary-dark text-white font-medium transition-colors disabled:opacity-50">
                  {saving ? "Saving..." : editingId ? "Update Course" : "Save Course"}
                </button>
              </div>
            </form>
          </div>
        )}

        {/* Courses Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {courses.map(course => (
            <div key={course.id} className="bg-white rounded-2xl border border-gray-100 overflow-hidden group">
              <div className="relative h-40">
                <Image src={course.image} alt={course.title} fill className="object-cover" />
              </div>
              <div className="p-4">
                <h3 className="font-bold text-gray-900 mb-1 line-clamp-1">{course.title}</h3>
                <p className="text-sm text-gray-500 mb-1">{course.instructor} · {course.duration}</p>
                {course.startDate && (
                  <p className="text-xs text-primary font-medium mb-2 flex items-center gap-1">
                    <Calendar className="w-3 h-3" /> Starts: {new Date(course.startDate).toLocaleDateString("en-GB")}
                  </p>
                )}
                <div className="flex items-center justify-between">
                  <span className="text-lg font-bold text-primary">৳{course.discountPrice || course.price}</span>
                  <div className="flex items-center gap-1">
                    <button onClick={() => startEdit(course)} className="p-2 rounded-lg text-blue-500 hover:bg-blue-50" title="Edit">
                      <Pencil className="w-4 h-4" />
                    </button>
                    <button onClick={() => handleDeleteCourse(course.id)} className="p-2 rounded-lg text-red-500 hover:bg-red-50" title="Delete">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
        {courses.length === 0 && (
          <div className="text-center py-20">
            <BookOpen className="w-12 h-12 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500 text-lg">No courses yet.</p>
            <p className="text-gray-400 text-sm">Click &quot;Add Course&quot; to create one.</p>
          </div>
        )}
      </div>
    </div>
  );
}
