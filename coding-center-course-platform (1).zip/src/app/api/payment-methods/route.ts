import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { paymentMethods } from "@/db/schema";

export async function GET() {
  try {
    const result = await db.select().from(paymentMethods);
    return NextResponse.json(result);
  } catch (error) {
    console.error("Payment methods error:", error);
    return NextResponse.json({ error: "Something went wrong" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const result = await db.insert(paymentMethods).values(body).returning();
    return NextResponse.json(result[0], { status: 201 });
  } catch (error) {
    console.error("Create payment method error:", error);
    return NextResponse.json({ error: "Something went wrong" }, { status: 500 });
  }
}
